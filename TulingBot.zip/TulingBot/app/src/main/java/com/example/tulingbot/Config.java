package com.example.tulingbot;

/**
 * 配置类
 */
public class Config {
    public static final String URL_KEY = "http://www.tuling123.com/openapi/api";
    public static final String APP_KEY = "11ba4a4fd488463d9417bb9611e10282";//此处是你申请的Apikey

}