package com.example.stopwatch;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class MyReceiver extends BroadcastReceiver {
    private String TAG = "MyReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.
        Log.d(TAG, "onReceive: ");
        String action = intent.getAction();
        if (action.equals("com.example.clock")){
String msg =intent.getStringExtra("msg");
            Toast.makeText(context,""+msg,Toast.LENGTH_SHORT).show();
            Log.d(TAG, "onReceive: clock");
        }
        if(action.equals("com.example.stopwatch")){
            Toast.makeText(context,"秒表",Toast.LENGTH_SHORT).show();
            Log.d(TAG, "onReceive: stopwatch");
        }
    }
}
