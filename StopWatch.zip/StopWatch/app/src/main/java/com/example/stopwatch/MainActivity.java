package com.example.stopwatch;

import android.content.Intent;
import android.content.IntentFilter;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private static String TAG = "MainActivity";
    private Button jump ;
    private Button clock;
    private MyReceiver myReceiver = new MyReceiver();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate: ");
        init();
        onClick();
    }

    private void init(){
        jump = findViewById(R.id.MainActivity_Jump);
        clock = findViewById(R.id.MainActivity_Clock);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("com.example.stopwatch");
        intentFilter.addAction("com.example.clock");
        registerReceiver(myReceiver,intentFilter);
    }
    private void onClick(){
        jump.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent("com.example.stopwatch");
                sendBroadcast(intent);
                intent.setClass(MainActivity.this,StopClock.class);
                startActivity(intent);
            }
        });
        clock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent("com.example.clock");
                intent.putExtra("msg","闹钟");
                sendBroadcast(intent);
                intent.setClass(MainActivity.this,ClockActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(myReceiver);
    }
}
