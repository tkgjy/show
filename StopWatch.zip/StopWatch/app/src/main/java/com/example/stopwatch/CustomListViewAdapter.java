package com.example.stopwatch;

import android.widget.ArrayAdapter;

public class CustomListViewAdapter extends ArrayAdapter {
}
