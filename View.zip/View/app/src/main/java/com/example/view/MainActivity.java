package com.example.view;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.view.CustomFragment;
import com.example.view.R;
import com.example.view.TitleBar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TitleBar titleBar = findViewById(R.id.title_bar);
        titleBar.setLeftButtonListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "点击了返回按钮", Toast.LENGTH_SHORT)
                        .show();
                finish();
            }

        });

        Button addOrDel = findViewById(R.id.add_or_del);
        addOrDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CustomFragment customFragment = (CustomFragment) getSupportFragmentManager()
                        .findFragmentByTag("customFragment");
                if (null != customFragment && customFragment.isVisible()) {
                    getSupportFragmentManager().beginTransaction()
                            .remove(customFragment)
                            .commit();
                } else {
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.fragment_content, new CustomFragment(), "customFragment");
                    if (getSupportFragmentManager().getBackStackEntryCount() < 1)
                        fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();

                }
            }
        });

        Button broswer = findViewById(R.id.broswer);
        broswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("http://www.baidu.com"));
                startActivity(intent);
            }
        });

        ObjectAnimator animator = ObjectAnimator.ofFloat(addOrDel,"rotation",0,180,0);
        animator.setDuration(2000);
        animator.start();

    }
}
