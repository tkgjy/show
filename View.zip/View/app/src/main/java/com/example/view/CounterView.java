package com.example.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public class CounterView extends View {

    // 定义画笔
    private Paint mPaint;
    // 用于获取文字的宽和高
    private Rect mBounds;
    // 计数值，每点击一次本控件，其值增加1
    private int mCount;

    private float mX;

    // XML 静态定义使用
    public CounterView(Context context, AttributeSet attrs) {
        super(context, attrs);

        // 初始化画笔、Rect
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mBounds = new Rect();
    }

    // JAVA 动态定义使用
    public CounterView(Context context) {
        super(context);

        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mBounds = new Rect();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        //第一步获取宽和高的模式和大小,系统提供了MeasureSpec
        int widthMode = MeasureSpec.getMode(widthMeasureSpec);  //宽尺寸模式
        int widthSize = MeasureSpec.getSize(widthMeasureSpec);  //宽大小
        int heightMode = MeasureSpec.getMode(heightMeasureSpec);//高尺寸模式
        int heightSize = MeasureSpec.getSize(heightMeasureSpec);//高大小

        int width, height;

        Log.d("CounterView onMeasure:", "before width=" + widthSize + " height=" + heightSize);
        if (widthMode == MeasureSpec.EXACTLY) {//给定大小的模式,对应于match_parent和指定宽高的模式
            width = widthSize;
        } else {
            width = widthSize / 2;
        }

        if (heightMode == MeasureSpec.AT_MOST) { // warp_content
            height = heightSize / 3;
        } else {
            height = heightSize;
        }
        Log.d("CounterView onMeasure:", "after width=" + width + " height=" + height);

        setMeasuredDimension(width, height);
        mX = width / 2;
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);

    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        mPaint.setColor(Color.BLUE);
        // 绘制一个填充色为蓝色的圆
        canvas.drawCircle(mX, getHeight() / 2, 200, mPaint);

        mPaint.setColor(Color.GREEN);
        mPaint.setTextSize(50);
        String text = String.valueOf(mCount);
        // 获取文字的宽和高
        mPaint.getTextBounds(text, 0, text.length(), mBounds);
        float textWidth = mBounds.width();
        float textHeight = mBounds.height();

        // 绘制字符串
        canvas.drawText(text, getWidth() / 2 - textWidth / 2, getHeight() / 2
                + textHeight / 2, mPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_MOVE:
                mX = event.getX();
                if (mX > getWidth() / 2) mCount++;
                if (mX > 200 && mX < getWidth() - 200) invalidate();

                break;
            case MotionEvent.ACTION_DOWN:
                mX = event.getX();
                if (mX > getWidth() / 2) mCount++;
                if (mX > 200 && mX < getWidth() - 200) invalidate();

                break;
            default:
                break;
        }

        return true;
    }

}
